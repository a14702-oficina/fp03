<?php
try {
  $pdo = new PDO("mysql:host=sql300.infinityfree.com;dbname=if0_40156181_modulo5_db;charset=utf8", "if0_40156181", "3lxGnvbpQ1rU3");
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Erro na ligação: " . $e->getMessage());
}
?>