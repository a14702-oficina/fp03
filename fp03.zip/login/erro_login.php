<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Falha no Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      border-radius: 1rem;
    }
    .card-title {
      font-weight: bold;
    }
    .btn-primary {
      min-width: 120px;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">Sistema de Login</a>
    </div>
  </nav>

  <!-- Main Content -->
  <main class="container py-5">
    <div class="row justify-content-center">
      <div class="col-12 col-md-8 col-lg-6">
        <div class="card shadow-sm text-center">
          <div class="card-body p-5">
            <h3 class="card-title mb-3 text-danger">Falha no Login</h3>
            <p class="mb-4 lead">Não foi possível autenticar a sua conta. Verifique o nome de utilizador e senha e tente novamente.</p>
            <a href="index.php" class="btn btn-primary btn-lg">Tentar Novamente</a>
          </div>
        </div>
      </div>
    </div>
  </main>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
