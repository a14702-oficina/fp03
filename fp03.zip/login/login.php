<?php
session_start();

$ligacao = new mysqli("sql300.infinityfree.com", "if0_40156181", "3lxGnvbpQ1rU3", "if0_40156181_modulo5_db"); 

if ($ligacao->connect_error) {
    die("Erro na ligação: " . $ligacao->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];

// Query segura
$stmt = $ligacao->prepare("SELECT password FROM utilizadores WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// Verifica se encontrou o username
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();

    if ($password === $row['password']) {
        header("Location: ../m5-crud/index.php");
        exit();
    }
}

header("Location: erro_login.php");
exit();
?>
