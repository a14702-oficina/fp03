<?php
include "conexao.php";

$stmt = $pdo->prepare("SELECT * FROM alunos ORDER BY id DESC");
$stmt->execute();
$alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Alunos — CRUD Inline</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <nav class="navbar navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="index.php">CRUD - Alunos (CRUD Inline)</a>
      <a class="btn btn-outline-light" href="alunos_form.php">+ Novo Aluno</a>
    </div>
  </nav>

  <main class="container py-4">
    <div class="row">
      <div class="col-12 col-lg-10 mx-auto">
        <?php if(isset($_GET['ok'])): ?>
          <div class="alert alert-success">Operação concluída.</div>
        <?php endif; ?>

        <div class="card shadow-sm">
          <div class="card-body">
            <h3 class="card-title mb-3">Lista de Alunos</h3>
            <table class="table table-striped align-middle">
              <thead>
                <tr>
                  <th style="width:5%">#</th>
                  <th>Nome</th>
                  <th>Email</th>
                  <th class="text-end" style="width:20%">Ações</th>
                </tr>
              </thead>
              <tbody>
                <?php if(!$alunos): ?>
                  <tr><td colspan="4" class="text-center text-muted py-4">Sem alunos.</td></tr>
                <?php else: ?>
                  <?php foreach($alunos as $a): ?>
                    <tr>
                      <form action="alunos_editar.php" method="POST">
                        <td>
                          <?php echo htmlspecialchars($a['id']); ?>
                          <input type="hidden" name="id" value="<?php echo htmlspecialchars($a['id']); ?>">
                        </td>
                        <td><input type="text" name="nome" class="form-control" value="<?php echo htmlspecialchars($a['nome']); ?>" required maxlength="100"></td>
                        <td><input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($a['email']); ?>" required maxlength="150"></td>
                        <td class="text-end">
                          <button class="btn btn-warning btn-sm">Guardar</button>
                          <a class="btn btn-danger btn-sm"
                             onclick="return confirm('Eliminar o aluno #<?php echo htmlspecialchars($a['id']); ?>?');"
                             href="alunos_apagar.php?id=<?php echo htmlspecialchars($a['id']); ?>">
                             Eliminar
                          </a>
                        </td>
                      </form>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </main>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>