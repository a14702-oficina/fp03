<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>CRUD - CRUD Inline</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <nav class="navbar navbar-dark bg-dark">
    <div class="container">
      <a class="navbar-brand" href="index.php">CRUD - CRUD Inline (PHP + PDO + Bootstrap)</a>
    </div>
  </nav>

  <main class="container py-4">
    <div class="row">
      <div class="col-12 col-lg-8 mx-auto">
        <div class="list-group shadow-sm">
          <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" href="alunos_lista.php">
            CRUD Inline - Alunos <span class="badge text-bg-primary">abrir</span>
          </a>
          <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" href="produtos_lista.php">
            CRUD Inline - Produtos <span class="badge text-bg-primary">abrir</span>
          </a>
        </div>

        <div class="alert alert-info mt-3">
          <strong>Nota:</strong> Importa primeiro o ficheiro <code>schema.sql</code> no phpMyAdmin para criares as tabelas.
        </div>
      </div>
    </div>
  </main>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>