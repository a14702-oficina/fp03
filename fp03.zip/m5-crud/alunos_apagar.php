<?php
include "conexao.php";
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if($id > 0){
  $stmt = $pdo->prepare("DELETE FROM alunos WHERE id=?");
  $stmt->execute([$id]);
}
header("Location: alunos_lista.php?ok=1");
exit;