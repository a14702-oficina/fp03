<?php
include "conexao.php";
$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
if($nome === '' || $email === ''){
  header("Location: alunos_lista.php"); exit;
}
$stmt = $pdo->prepare("INSERT INTO alunos (nome, email) VALUES (?, ?)");
$stmt->execute([$nome, $email]);
header("Location: alunos_lista.php?ok=1");
exit;