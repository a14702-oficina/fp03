<?php
include "conexao.php";
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
if($id > 0 && $nome !== '' && $email !== ''){
  $stmt = $pdo->prepare("UPDATE alunos SET nome=?, email=? WHERE id=?");
  $stmt->execute([$nome, $email, $id]);
}
header("Location: alunos_lista.php?ok=1");
exit;